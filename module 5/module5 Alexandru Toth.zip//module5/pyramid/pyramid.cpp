#include <iostream>

using namespace std;


void insert_spaces(int counter)
{
    for(int i = 0; i < counter; i++)
    {
        cout << " ";
    }
}
void insert_stars(int counter)
{
    for(int i = 0; i < counter; i++)
    {
        cout << '*';
    }
}
void representation()
{
    constexpr int rows = 10;
    int spaces = 24;
    int stars = 1;
    for(int i = 0; i < rows; i++)
    {
        insert_spaces(spaces);
        insert_stars(stars);
        cout << endl;
        spaces--;
        stars+= 2;
    }
}
int main()
{
    representation();
    return 0;
}
